//============================================================================
// Name        : BinarySearchTree.cpp
// Author      : William Fishburn
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <time.h>
#include <string>
#include <vector>

#include "CSVparser.hpp"

using namespace std;



//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);



// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string bidKey;
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

// Internal structure for tree node
struct Node {
    Bid bid;
    Node *left;
    Node *right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a bid
    Node(Bid aBid) :
            Node() {
        bid = aBid;
    }
};

// DLL Node
struct DLLNode {
    Bid bid;
    DLLNode* prev;
    DLLNode* next;

    DLLNode(Bid aBid) : bid(aBid), prev(nullptr), next(nullptr) {}
};


/**BST DLL Class Definition
Doubly Linked List*/
class DoublyLinkedList {
private:
    DLLNode* head;
    DLLNode* tail;

public:
    DoublyLinkedList() : head(nullptr), tail(nullptr) {}

    void append(Bid bid);
    void remove(string bidId);
    void display();
};

void DoublyLinkedList::append(Bid bid) {
    DLLNode* newNode = new DLLNode(bid);

    if (tail == nullptr) {
        head = tail = newNode;
    }
    else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
}

void DoublyLinkedList::remove(string bidId) {
    DLLNode* current = head;

    while (current != nullptr && current->bid.bidId != bidId) {
        current = current->next;
    }

    if (current != nullptr) {
        if (current->prev != nullptr) {
            current->prev->next = current->next;
        }
        else {
            head = current->next;
        }

        if (current->next != nullptr) {
            current->next->prev = current->prev;
        }
        else {
            tail = current->prev;
        }

        delete current;
    }
}
// Function prototype
void displayBid(Bid bid);
void DoublyLinkedList::display() {
    DLLNode* current = head;

    while (current != nullptr) {
        displayBid(current->bid);
        current = current->next;
    }
}

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;
    DoublyLinkedList dll; // Add a DLL to the BST

    void addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    Node* removeNode(Node* node, string bidId);
    
  

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Bid bid);
    Node* minValueNode(Node* node);
    void preOrder(Node* node);
    void postOrder(Node* node);
    void PreOrder();
    void PostOrder();
    void Remove(string bidId);
    Bid Search(string bidId);
    void displayDLL();
};


/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    // initialize housekeeping variables
    root = nullptr;
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
    // recurse from root deleting every node
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
    inOrder(root);
}

/**
 * Traverse the tree in post-order
 */
void BinarySearchTree::PostOrder() {
    postOrder(root);
}

/**
 * Traverse the tree in pre-order
 */
void BinarySearchTree::PreOrder() {
    preOrder(root);
}

/**
 * Insert a bid
 */
void BinarySearchTree::Insert(Bid bid) {
    // Implement inserting a bid into the tree
    // if root equarl to null ptr
    if (root == nullptr) {//if root has no value
        
        root = new Node(bid);//then set root equal to new node bid
    }
    else {
        // add Node root and bid
        addNode(root, bid);
    }
    dll.append(bid);
}
Node* BinarySearchTree::minValueNode(Node* node) {
    Node* current = node;

    // Find the leftmost leaf
    while (current->left != nullptr) {
        current = current->left;
    }

    return current;
}


/**
 * Remove a bid
 */
Node* BinarySearchTree::removeNode(Node* node, string bidId) {
    // Implementation to remove the node with the specified bidId
    if (node == nullptr) {
        // The bid with bidId is not found in the tree
        cout << "Bid Id " << bidId << " not found." << endl;
        return node;
    }

    if (bidId < node->bid.bidId) {
        // The bid is in the left subtree
        node->left = removeNode(node->left, bidId);
    }
    else if (bidId > node->bid.bidId) {
        // The bid is in the right subtree
        node->right = removeNode(node->right, bidId);
    }
    else {
        // Bid with bidId found, delete this node

        if (node->left == nullptr) {
            // Node with one child or no child
            Node* temp = node->right;
            delete node;
            return temp;
        }
        else if (node->right == nullptr) {
            // Node with one child
            Node* temp = node->left;
            delete node;
            return temp;
        }
        
        // Node with two children, get the inorder successor (smallest in the right subtree)
        Node* temp = minValueNode(node->right);

        // Copy the inorder successor's data to this node
        node->bid = temp->bid;

        // Delete the inorder successor
        node->right = removeNode(node->right, temp->bid.bidId);
    }

    return node;
    
}

void BinarySearchTree::Remove(string bidId) {
    root = removeNode(root, bidId);
    dll.remove(bidId);
    
}

/**
 * Search for a bid
 */
Bid BinarySearchTree::Search(string bidId) {
    //Search tree for a bid
    Node* current = root;

    while (current != nullptr) {
        if (bidId == current->bid.bidId) {
            cout << "Found Bid: ";
            
            return current->bid;
        }
        else if (bidId < current->bid.bidId) {
            current = current->left;
        }
        else {
            current = current->right;
        }
    }
    Bid bid;
    return bid;
}

/**
 * Add a bid to some node (recursive)
 *
 * @param node Current node in tree
 * @param bid Bid to be added
 */
void BinarySearchTree::addNode(Node* node, Bid bid) {
    // if node is larger, add to the left
    if (bid.bidId < node->bid.bidId) {
        // if no left node, this node becomes left
        if (node->left == nullptr) {
            node->left = new Node(bid);
        }
        else {
            // else recurse down the left node
            addNode(node->left, bid);
        }
    }
    else {
        // if no right node, this node becomes right
        if (node->right == nullptr) {
            node->right = new Node(bid);
        }
        else {
            // else recurse down the right node
            addNode(node->right, bid);
        }
    }
}

void displayBid(Bid bid);
void BinarySearchTree::inOrder(Node* node) {
    if (node != nullptr) {
        // Traverse the left subtree
        inOrder(node->left);

        // Display bid information
        displayBid(node->bid);

        // Traverse the right subtree
        inOrder(node->right);
    }
}

void BinarySearchTree::displayDLL() {
    dll.display();
}

void BinarySearchTree::postOrder(Node* node) {
    // if node is not equal to null ptr
    if (node != nullptr) {
        // postOrder left
        postOrder(node->left);

        // postOrder right
        postOrder(node->right);

        // output bidID, title, amount, fund
        displayBid(node->bid);
    }
}

void BinarySearchTree::preOrder(Node* node) {
    // if node is not equal to null ptr
    if (node != nullptr) {
        // output bidID, title, amount, fund
        displayBid(node->bid);

        // preOrder left
        preOrder(node->left);

        // preOrder right
        preOrder(node->right);
    }
}

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
void loadBids(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row - optional
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {
        // loop to read rows of a CSV file
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            //cout << "Item: " << bid.title << ", Fund: " << bid.fund << ", Amount: " << bid.amount << endl;

            // push this bid to the end
            bst->Insert(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98109";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        bidKey = "98109";
    }

    // Define a timer variable
    clock_t ticks;

    // Define a binary search tree to hold all bids
    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  5. Display Doubly Linked List" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            
            // Initialize a timer variable before loading bids
            ticks = clock();

            // Complete the method call to load the bids
            loadBids(csvPath, bst);

            //cout << bst->Size() << " bids read" << endl;

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            bst->InOrder();
            break;

        case 3:
            
            cout << "Enter Bid Id: ";
            cin >> bidKey; // Prompt the user for the Bid Id

            ticks = clock();

            bid = bst->Search(bidKey);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            if (!bid.bidId.empty()) {
                displayBid(bid);
            } else {
            	cout << "Bid Id " << bidKey << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 4:
            cout << "Enter Bid ID to remove: ";
            cin >> bidKey;
            bst->Remove(bidKey);
            cout << "Bid with ID " << bidKey << " removed." << endl;
            break;

        case 5:
            bst->displayDLL();
            break;

        }
    }

    cout << "Good bye." << endl;

	return 0;
}
