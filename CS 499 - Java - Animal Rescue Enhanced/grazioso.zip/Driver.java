import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;


public class Driver {
    
	private static ArrayList<Dog> dogList = new ArrayList<>();   
   
	
    private static ArrayList<Monkey> monkeyList = new ArrayList<>();
    	

    public static void main(String[] args) {
    	
    	Dog dog1= new Dog("Dog", "Fido", "GSD", "4.3", "5.7", "male", "7",
    		    "20", "2", "now", "USA", 
    			"in service", false, "USA");
        
    	dogList.add(dog1);
    	
    	
    	Monkey monkey1 = new Monkey( "Monkey", "EEK", "female", "Capuchin", "16", "5", "3", "3", "4", "09-23-2019",
				"USA", "in service", false, "USA");
		
		monkeyList.add(monkey1);
    	
    
        Scanner input = new Scanner(System.in);
        char choice;
        
        //Loop until the application is exited by the user
        
        do {
        	displayMenu();
        	choice= input.next().charAt(0);
        	if(choice == '1') {
        		intakeNewDog(input);
        	
        	}
        	else if (choice == '2') {
        		intakeNewMonkey(input);
        	}
        	
        	else if (choice == '3') {
        		reserveAnimal(input);
        		
        	}
        	
        	else if (choice == '4') {
        		printAnimals(choice);//this prints the Dog list
        	}
        	
        	else if (choice == '5') {
        		printAnimals(choice);//this prints the Monkey list
        	}
        	
        	else if (choice == '6') {
        		printAnimals(choice);//prints all animals
        	
        	}
        	
        	else if (choice == 'q') {
        		System.out.print("Exiting application. See ya!");
        		break;
        	}
        	
        	else {//Invalid input handling
        		System.out.println("Invalid input. Please try again.");
        	}
        }
        
        while (choice !='q');

	

    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }

  
    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list
    // is done for you
       
    public static void intakeNewDog(Scanner scanner) {
       String name= " ";
       String animalTypes = "Dog, dog";
      
    	try {
    		
    		System.out.println("What is the Animal Type?");
            String animalType = scanner.next();
            if(!animalTypes.contains(animalType)) {
        		System.out.println("Animal type unavailable. Please enter 'Dog' or 'dog'.");
        		return;
        	}else {
        		scanner.nextLine();
        	}
    		
    		System.out.println("What is the dog's name?");
            name = scanner.next().trim();
            
            for(Dog dog: dogList) {
                if(dog.getName().equalsIgnoreCase(name)) {
                    System.out.println("\n\nThis dog is already in our system\n\n");
                    return; //returns to menu
                }
        	}
           
            scanner.nextLine();
            
            System.out.println("Dog's breed?");
            String species = scanner.nextLine();
           
            
            
            System.out.println("Dog's gender?");
            String gender = scanner.next();
            scanner.nextLine();
            
            System.out.println("Dog's age?");
            String age = scanner.next();
            scanner.nextLine();
            
            System.out.println("Dog's height?");
            String height = scanner.next();
            scanner.nextLine();
            
            System.out.println("Dog's weight?");
            String weight = scanner.next();
            scanner.nextLine();
            
            System.out.println("Dog's tail length?");
            String tailLength = scanner.next();
            scanner.nextLine();
            
            System.out.println("Dog's body length?");
            String bodyLength = scanner.next();
            scanner.nextLine();
            
            System.out.println("Dog's acquisition date?");
            String acquisitionDate = scanner.next();
            scanner.nextLine();
            
            System.out.println("Dog's acquisition country?");
            String acquisitionCountry = scanner.nextLine();
            
            
            System.out.println("Dog's training status?");
            String trainingStatus = scanner.nextLine().toLowerCase();
            
            
            System.out.println("Is the Dog reserved?");
            boolean reserved = scanner.nextBoolean();
            scanner.nextLine();
            
            System.out.println("What is the Dog's country of service?");
            String inServiceCountry = scanner.nextLine();
           
            
            Dog dog = new Dog(animalType, name, species, tailLength, bodyLength, gender, age,
	    		    weight, height, acquisitionDate, acquisitionCountry, 
	    			trainingStatus, reserved, inServiceCountry);
            
            dogList.add(dog);
                       
            System.out.println("Your dog has been added to the list!");
            dog.setTrainingStatus("in service");
      
    		}catch(InputMismatchException e) {
    			System.out.println("Sorry, wrong input type."
    					+ " For reservation status, please say 'true' or 'false'.");
    			scanner.next();
    		}
    	
	    	
	    	 	   
	    	
    }      
       
     //Monkey intake method
    		
            public static void intakeNewMonkey(Scanner input) {
            	String name = null;//Initialize name variable
            	//Create a list to store breed values
            	//List<String >breed = new ArrayList<String>();
            	
            	/*breed.add("Capuchin");
            	breed.add("Guenon");
            	breed.add("Macaque");
            	breed.add("Squirrel Monkey");
            	breed.add("Marmoset");
            	breed.add("Tamarin");*/
            	
            	String breed = "capuchin, guenon, macaque, squirrel Monkey, marmoset, tamarin";
            	String animalTypes = "Monkey, monkey";
            	            
            	try {//try block for input validation/Exception handling

            	
    		    System.out.println("Animal Type?");
                String animalType = input.next();
                if(!animalTypes.contains(animalType)) {
                	System.out.println("Animal type unavailable. Please enter 'Monkey' or 'monkey'.");
            		return;
                }
                input.nextLine();
            	System.out.println("What is the monkey's name?");
            	name = input.next();
            	for(Monkey m: monkeyList) {
                    if(m.getName().equalsIgnoreCase(name)) {
                        System.out.println("\n\nThis monkey is already in our system\n\n");
                  
                          return; //returns to menu
                          
                    }
        		}   
              
               	input.nextLine();
               	System.out.println("Monkey's age?");
                String age = input.next();
                input.nextLine();
                System.out.println("Monkey's species?");
                String species = input.nextLine().toLowerCase();
                	 if(!breed.contains(species)) {
                			System.out.println("This species is not available for intake. "
                					+ "Please call ###-###-#### for updates!");
                			return;
                		}
                	
                	
               
                System.out.println("Monkey's gender?");
                String gender = input.next();
                input.nextLine();
                System.out.println("Monkey's weight?");
                String weight = input.next();
                input.nextLine();
                System.out.println("Monkey's tail length?");
                String tailLength = input.next();
                input.nextLine();
                System.out.println("Monkey's height?");
                String height = input.next();
                input.nextLine();
                System.out.println("Monkey's body length?");
                String bodyLength = input.next();
                input.nextLine();
                System.out.println("Monkey's acquisition date?");
                String acquisitionDate = input.next();
                input.nextLine();
                System.out.println("Monkey's acquisition country?");
                String acquisitionCountry = input.next();
                input.nextLine();
                System.out.println("Monkey's training status?");
                String trainingStatus = input.nextLine().toLowerCase();
                
                System.out.println("Monkey's reservation status? Say 'true' or 'false'.");
                boolean reserved = input.nextBoolean();
                input.nextLine();
                System.out.println("Monkey's country of service?");
                String inServiceCountry = input.next();
                input.nextLine();
                
                Monkey monkey = new Monkey(animalType, name, species, tailLength, bodyLength, gender, age,
     	    		    weight, height, acquisitionDate, acquisitionCountry, 
     	    			trainingStatus, reserved, inServiceCountry);
                 
                 monkeyList.add(monkey);
                 
                 System.out.println("Monkey added to the list!");
           
            		
            	}catch(InputMismatchException e) {
                	   System.out.println("Sorry, wrong input type. "
                	   		+ " For reservation status, please input 'true' or 'false'");
                  	   input.next();
            		
            	}
            	 
            }      

        // You will need to find the animal by animal type and in service country
        public static void reserveAnimal(Scanner scanner) {
           
        	String animalType=" ";
        	       	
        	System.out.println("Enter animal type.");
        	
        	try {
        	animalType = scanner.next().toLowerCase();
        	
        	
        	       	
            //BEGIN IF statement for monkey reservation
        		if(animalType.equalsIgnoreCase("monkey")) {
            		
            	System.out.println("Enter Monkey's in service country.");
            	String country = scanner.next().toUpperCase();
            	for (Monkey m: monkeyList) {
            		if(m.getInServiceCountry().equalsIgnoreCase(country)&& m.getReserved()==false) {
            			m.setReserved(true);
            			System.out.println("Monkey is reserved: complete!");
            			return;
            		
            		}else {
            			System.out.println("Monkeys are currently unavailable in this country. "
            					+ "Please call ###-###-#### for reservation updates. We look forward to hearing from you!");
            		
            			}	
            	}
            	
            	
                
                //BEGIN ELIF statement for Dog reservation
            	
            }else if (animalType.equalsIgnoreCase("Dog")) {
            	System.out.println("Enter Dog's in service country");
            	String country = scanner.next().toUpperCase();
            	for (Dog d: dogList) {
            		if(d.getInServiceCountry().equalsIgnoreCase(country) && d.getReserved()==false && d.getTrainingStatus().equals("in service")) {
            			d.setReserved(true);
            			System.out.println("Dog is now reserved: complete!");
            			return;
            		}else {
            			System.out.println("Dogs are currently unavailable in this country. "
            					+ "Please call ###-###-#### for reservation updates. We look forward to hearing from you!");
            		}	
            	}
            }
        	
            else if(animalType!=("Dog") || animalType!=("dog")|| animalType!=("monkey") || animalType!=("Monkey")) {
            		System.out.println("Animal type unavailable. Please enter 'monkey' or 'dog'");
            	}
        }catch(Exception e){
        	System.out.println("Something went wrong.");
        }
    }

        // Complete printAnimals
        // Include the animal name, status, acquisition country and if the animal is reserved.
	// Remember that this method connects to three different menu items.
        // The printAnimals() method has three different outputs
        // based on the listType parameter
        // dog - prints the list of dogs
        // monkey - prints the list of monkeys
        // available - prints a combined list of all animals that are
        // fully trained ("in service") but not reserved 
	// Remember that you only have to fully implement ONE of these lists. 
	// The other lists can have a print statement saying "This option needs to be implemented".
	// To score "exemplary" you must correctly implement the "available" list.
        
        
        public static void printAnimals(char choice) {
            if(choice == '4') {
            	              
            	System.out.println(dogList);//prints entire dog list
            }
            else if(choice=='5') {
            	System.out.println(monkeyList);//prints entire monkey list
       
            }
            
            else if(choice == '6') {//returns available dogs that aren't reserved
            	for(int i=0; i< dogList.size(); i++) {
            		if(dogList.get(i).getTrainingStatus().equals("in service") && dogList.get(i).getReserved()==false) {
            			System.out.println(dogList.get(i));
            		}else  {
            			System.out.println("There are no available dogs. "
            					+ "Please call ###-###-#### for availability. We look forward to hearing from you!");
            		}
            		
            		{
            			
            		}
            	}
            
            	for(int i=0; i<monkeyList.size(); i++) {//returns available monkeys that aren't reserved
            		if(monkeyList.get(i).getTrainingStatus().equals("in service") && monkeyList.get(i).getReserved()==false) {
            			System.out.println(monkeyList.get(i));
            		}else {
            			System.out.println("There are no available monkeys. "
            					+ "Please call ###-###-#### for availability. We look forward to hearing from you!");
            		}		
            
            	}
           
        }
   
     }
}

