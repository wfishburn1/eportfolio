
public class Monkey extends RescueAnimal{
	
	//Create instance variables
	private String tailLength;
	private String height;
	private String bodyLength;
	private String species;
	
	//Detailed constructor
	
	
	public Monkey ( String animalType, String name, String gender, String species, String age, String weight, String tailLength, String bodyLength, String height, String acquisitionDate,
			String acquisitionCountry, String trainingStatus, 
			boolean reserved, String inServiceCountry) {
		
		
		this.name=name;
		this.gender=gender;
		this.species=species;
		this.age=age;
		this.weight=weight;
		this.tailLength=tailLength;
		this.bodyLength=bodyLength;
		this.height=height;
		this.acquisitionDate=acquisitionDate;
		this.acquisitionCountry=acquisitionCountry;
		this.trainingStatus=trainingStatus;
		this.inServiceCountry=inServiceCountry;
		this.reserved=reserved;
		this.animalType=animalType;
			
		
		
		
	}
	
		//No arg constructor
	public Monkey() {
		
	}
	
	
	//Setters
	
	public void setAnimalType(String animalType) {
		this.animalType=animalType;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public void setGender(String gender) {
		this.gender=gender;
	}
	public void setSpecies(String species) {
		this.species=species;
		
	}

	public void setAge(String age){
		this.age=age;
	}
	
	public void setWeight(String weight){
		this.weight=weight;
	}
	
	public void setTailLength(String tailLength){
		this.tailLength=tailLength;
	}
	public void setBodyLength(String bodyLength) {
		this.bodyLength=bodyLength;
		
	}
	public void setHeight(String height) {
		this.height=height;
		
	}
		
	
	public void setAcquisitionDate(String acquisitionDate) {
		this.acquisitionDate = acquisitionDate;
	}
	
	public void setAcquisitionLocation(String acquisitionCountry) {
		this.acquisitionCountry=acquisitionCountry;
	}
	
	public void setTrainingStatus(String trainingStatus) {
		this.trainingStatus=trainingStatus;
	}
	
	public void setReserved(Boolean reserved) {
		this.reserved=reserved;
	}
	
	public void setInServiceCountry(String inServiceCountry) {
		this.inServiceCountry=inServiceCountry;
	}
	

	
	
	

	//Getters
	
	public String getName() {
		return name;
	}
	
	public String getAge() {
		return age;
	}
	
	public String getSpecies() {
		return species;
	}
	
	public String getGender() {
		return gender;
	
	}
	
	public String getTailLength() {
		return tailLength;
	}

	public String getHeight() {
		return height;
	}
	
	public String getWeight() {
		return weight;
	}
	public String gettailLength() {
		return tailLength;
	}

	public String getBodyLength() {
		return bodyLength;
	}

		
	public String getTrainingStatus() {
		return trainingStatus;
	}
	
	public String getInServiceCountry() {
		return inServiceCountry;
	}
	
	public boolean getReserved() {
		return reserved;
	}
	
	public String getAcquisitionDate() {
		return acquisitionDate;
	}
	
	public String getAcquisitionLocation() {
		return acquisitionCountry;
	}
	
	public String getAnimalType() {
		return animalType;
	}

	@Override
	public String toString() {
		return "Monkey [tailLength=" + tailLength + ", height=" + height + ", bodyLength=" + bodyLength + ", species="
				+ species + ", name=" + name + ", gender=" + gender + ", age=" + age + ", weight=" + weight
				+ ", acquisitionDate=" + acquisitionDate + ", acquisitionCountry=" + acquisitionCountry
				+ ", trainingStatus=" + trainingStatus + ", reserved=" + reserved + ", inServiceCountry="
				+ inServiceCountry + ", animalType=" + animalType + "]";
	}
	
	
}