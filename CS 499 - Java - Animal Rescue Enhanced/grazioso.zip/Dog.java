
public class Dog extends RescueAnimal {

    // Instance variable
    private String height;
    private String tailLength;
    private String bodyLength;
    private String species;
    

    // Constructor
    public Dog(String animalType, String name, String species, String tailLength, String bodyLength, String gender, String age,
    String weight, String height, String acquisitionDate, String acquisitionCountry, 
	String trainingStatus, boolean reserved, String inServiceCountry) {
    	
    	this.animalType=animalType;  
        this.name=name;
        this.species=species;          
        this.tailLength=tailLength;               
    	this.bodyLength=bodyLength;                
        this.gender=gender;
        this.age=age;                
        this.weight=weight;
        this.height=height;       
        this.acquisitionDate=acquisitionDate;
        this.acquisitionCountry=acquisitionCountry;        
        this.trainingStatus=trainingStatus;
        this.reserved=reserved;              
        this.inServiceCountry=inServiceCountry;        
           
    }
    	//Mutators
    
    	public void setAnimalType(String animalType) {
    		this.animalType=animalType;
    	}	


        public void setName(String name) {
        	this.name=name;
        }
        public void setSpecies(String species) {
        	this.species=species;
        }
        
        public void setTailLength(String tailLength) {
        	this.tailLength=tailLength;
        }
        public void setBodyLength(String bodyLength) {
        	this.bodyLength=bodyLength;
        }
        
        public void setGender(String gender) {
        	this.gender=gender;
        }
        
        public void setAge(String age) {
        	this.age=age;
        }
        
        public void setWeight(String weight) {
        	this.weight=weight;
        }	
        public void setHeight(String height) {
        	this.height=height;
        }
        public void setAcquisitionDate(String acquisitionDate) {
        	this.acquisitionDate=acquisitionDate;
        }
        
        public void setAcquisitionCountry(String acquisitionCountry) {
        	this.acquisitionCountry=acquisitionCountry;
        }
        
        
        public void setTrainingStatus(String trainingStatus) {
        	this.trainingStatus=trainingStatus;
        }
        
        public void setReserved(boolean reserved) {
        	this.reserved=reserved;
        }
        
        public void setInServiceCountry(String inServiceCountry) {
        	this.inServiceCountry=inServiceCountry;
        }
        
        
	// Accessor Methods
   
    public String getName() {
        return name;
    }
    public String getSpecies() {
        return species;
    }
    public String getTailLength() {
    	return tailLength;
    }
    public String getBodyLength() {
    	return bodyLength;
    }
   
    public String getGender() {
    	return gender;
    }
    public String getAge() {
    	return age;
    }
    public String getWeight() {
    	return weight;
    }
    
    public String getHeight() {
    	return height;
    }
    
    public String getAcquisitionDate() {
    	return acquisitionDate;
    }
    
    public String getAcquisitionCountry() {
		return acquisitionCountry;
	}

    
    public String getTrainingStatus() {
    	return trainingStatus;
    }
    
    public boolean getReserved() {
    	return reserved;
    }
    
    public String getInServiceCountry() {
    	return inServiceCountry;
    }
	
    public String getAnimalType() {
    	return animalType;
    }

	@Override
	public String toString() {
		return "Dog [height=" + height + ", tailLength=" + tailLength + ", bodyLength=" + bodyLength + ", species="
				+ species + ", name=" + name + ", gender=" + gender + ", age=" + age + ", weight=" + weight
				+ ", acquisitionDate=" + acquisitionDate + ", acquisitionCountry=" + acquisitionCountry
				+ ", trainingStatus=" + trainingStatus + ", reserved=" + reserved + ", inServiceCountry="
				+ inServiceCountry + ", animalType=" + animalType + "]";
	}	
     
}

    
